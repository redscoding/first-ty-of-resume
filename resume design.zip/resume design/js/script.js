/*===============typing animation====*/

var typed = new Typed(".typing" , {

    strings:["","SOFTWARE ENGINEERING","WEB DESIGNING ","CODING"],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})